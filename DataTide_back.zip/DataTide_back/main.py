# main.py
from fastapi import FastAPI
from DataTide_back.routers import ground_weather, items
from DataTide_back.routers import sample

app = FastAPI()

app.include_router(ground_weather.router)
app.include_router(items.router)
app.include_router(sample.router, prefix="/sample")

@app.get("/", tags=["Root"])
async def read_root():
    return {"message": "DataTide Backend API에 오신걸 환영합니다!"}
